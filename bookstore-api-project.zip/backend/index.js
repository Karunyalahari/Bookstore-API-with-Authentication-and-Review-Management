
const express = require('express');
const bodyParser = require('body-parser');
const { books, users } = require('./data');

const app = express();
app.use(bodyParser.json());

const PORT = 5000;

// General Users
app.get('/books', (req, res) => {
  res.json(books);
});

app.get('/books/:isbn', (req, res) => {
  const book = books[req.params.isbn];
  if (book) res.json(book);
  else res.status(404).send('Book not found');
});

app.get('/books/author/:author', (req, res) => {
  const result = Object.values(books).filter(book =>
    book.author.toLowerCase() === req.params.author.toLowerCase()
  );
  res.json(result);
});

app.get('/books/title/:title', (req, res) => {
  const result = Object.values(books).filter(book =>
    book.title.toLowerCase().includes(req.params.title.toLowerCase())
  );
  res.json(result);
});

app.get('/review/:isbn', (req, res) => {
  const book = books[req.params.isbn];
  if (book) res.json(book.reviews);
  else res.status(404).send('Book not found');
});

// Registered Users
app.post('/register', (req, res) => {
  const { username, password } = req.body;
  if (users.find(u => u.username === username)) {
    return res.status(400).json({ message: 'User already exists' });
  }
  users.push({ username, password });
  res.json({ message: 'User registered successfully' });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);
  if (user) res.json({ message: 'Login successful', username });
  else res.status(401).json({ message: 'Invalid credentials' });
});

app.put('/auth/review/:isbn', (req, res) => {
  const { username, review } = req.body;
  const isbn = req.params.isbn;
  if (books[isbn]) {
    books[isbn].reviews[username] = review;
    return res.json({ message: 'Review added/updated', reviews: books[isbn].reviews });
  }
  res.status(404).send('Book not found');
});

app.delete('/auth/review/:isbn', (req, res) => {
  const { username } = req.body;
  const isbn = req.params.isbn;
  if (books[isbn] && books[isbn].reviews[username]) {
    delete books[isbn].reviews[username];
    return res.json({ message: 'Review deleted' });
  }
  res.status(404).send('Review not found');
});

app.listen(PORT, () => {
  console.log(`Bookstore API running at http://localhost:${PORT}`);
});
