
const books = {
  '1111111111': {
    isbn: '1111111111',
    title: 'Node.js for Beginners',
    author: 'John Doe',
    reviews: {}
  },
  '2222222222': {
    isbn: '2222222222',
    title: 'Advanced JavaScript',
    author: 'Jane Smith',
    reviews: {}
  }
};

const users = [];

module.exports = { books, users };
