
const axios = require('axios');

async function getBooksByTitle(title) {
  try {
    const response = await axios.get(`http://localhost:5000/books/title/${title}`);
    console.log(`Books with title "${title}":\n`, response.data);
  } catch (err) {
    console.error(`Error fetching books by title "${title}":`, err.message);
  }
}

getBooksByTitle('Node.js');
