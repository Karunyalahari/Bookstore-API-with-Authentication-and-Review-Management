
const axios = require('axios');

function getBookByISBN(isbn) {
  axios.get(`http://localhost:5000/books/${isbn}`)
    .then(response => {
      console.log(`Book with ISBN ${isbn}:\n`, response.data);
    })
    .catch(error => {
      console.error(`Error fetching book with ISBN ${isbn}:`, error.message);
    });
}

getBookByISBN('1111111111');
