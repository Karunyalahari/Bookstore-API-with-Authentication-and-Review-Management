
const axios = require('axios');

async function getBooksByAuthor(author) {
  try {
    const response = await axios.get(`http://localhost:5000/books/author/${author}`);
    console.log(`Books by ${author}:\n`, response.data);
  } catch (err) {
    console.error(`Error fetching books by ${author}:`, err.message);
  }
}

getBooksByAuthor('John Doe');
