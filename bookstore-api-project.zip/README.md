
# 📚 Bookstore API Project

This project demonstrates a simple bookstore API with Node.js and Express, and Node.js scripts using Axios to interact with it.

## 🚀 Getting Started

### Install dependencies
```bash
npm install express body-parser axios
```

### Run Backend Server
```bash
node backend/index.js
```

### Run Node Scripts
```bash
node node-scripts/getAllBooks.js
node node-scripts/searchByISBN.js
node node-scripts/searchByAuthor.js
node node-scripts/searchByTitle.js
```

## 📂 Directory Structure

- `backend/` – Express.js server code
- `node-scripts/` – Axios-based scripts for testing
- `screenshots/` – Put your task output screenshots here
